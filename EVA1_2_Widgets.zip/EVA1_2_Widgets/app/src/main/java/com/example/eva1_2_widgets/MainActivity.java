package com.example.eva1_2_widgets;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView txtVwMensa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtVwMensa = findViewById(R.id.txtVwMensaje);
        txtVwMensa.setText("Hello android programming world, Soy un chavo y estas viendo Disney Channel (ta tara ta)");
        txtVwMensa.setText(R.string.mi_cadena);

    }
}

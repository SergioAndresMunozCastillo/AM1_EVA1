package com.example.eva1_7_screen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    Button btnBoton;
    TextView txtMen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        btnBoton = findViewById(R.id.btnBoton);
        txtMen = findViewById(R.id.txtMen);

        btnBoton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtMen.append("THANOSCAR");
            }
        });

        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
            Log.wtf("Pantalla", "Modo porttrait");

        }else{
            Log.wtf("Pantalla", "Modo Landscape");
        }

    }
}

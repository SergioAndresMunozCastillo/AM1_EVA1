package com.example.eva1_4_eventos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener{
    Button btnPorInt, btnPorClaseAn, btnPorClaseEx;
    MiEventoClick eve = new MiEventoClick();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnPorInt = findViewById(R.id.btnPorInt);
        btnPorClaseAn = findViewById(R.id.btnPorClaseAn);
        btnPorClaseEx = findViewById(R.id.btnPorClaseEx);

        btnPorInt.setOnClickListener(this);
        btnPorClaseAn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Evento implementando una clase anónima.", Toast.LENGTH_LONG).show();
            }
        });
        eve.setContext(this);
        btnPorClaseEx.setOnClickListener(eve);

    }

    @Override
    public void onClick(View view) {
        Toast.makeText(this, "Evento con métodos de una interfaz.", Toast.LENGTH_SHORT).show();
    }

    public void miClick(View v){

        Toast.makeText(this, "Evento implementado con XML", Toast.LENGTH_SHORT).show();
    }
}

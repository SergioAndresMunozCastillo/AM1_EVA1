package com.example.eva1_5_radio_group;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {

    RadioGroup rdgrpComida;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rdgrpComida = findViewById(R.id.rdgrpComida);
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        String sMensa = "";

        if(i == R.id.rdBtnTacos){
            sMensa = "Tacos";
        }else if(i == R.id.rdBtnFlautas) {
            sMensa = "Flautas";
        }else if(i == R.id.rdBtnRatatouille){
            sMensa = "Ratatouille";
        }
        Toast.makeText(this, sMensa, Toast.LENGTH_LONG).show();

    }
}
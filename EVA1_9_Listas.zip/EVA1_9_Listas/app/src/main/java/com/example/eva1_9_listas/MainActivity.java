package com.example.eva1_9_listas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements ListView.OnItemClickListener{

    TextView t;
    ListView lista;
    String[] asResta = {
        "Accion poetica",
            "Ayer pase por tu casa y me apuntaste con un revolver",
            "Desde ese día juré no vólver.",
            "Accion poetica",
            "Ayer pase por tu casa y me apuntaste con un revolver",
            "Desde ese día juré no vólver.",
            "Accion poetica",
            "Ayer pase por tu casa y me apuntaste con un revolver",
            "Desde ese día juré no vólver.",
            "Accion poetica",
            "Ayer pase por tu casa y me apuntaste con un revolver",
            "Desde ese día juré no vólver.",
            "Accion poetica",
            "Ayer pase por tu casa y me apuntaste con un revolver",
            "Desde ese día juré no vólver.",
            "Accion poetica",
            "Ayer pase por tu casa y me apuntaste con un revolver",
            "Desde ese día juré no vólver.",
            "Accion poetica",
            "Ayer pase por tu casa y me apuntaste con un revolver",
            "Desde ese día juré no vólver.",
            "Accion poetica",
            "Ayer pase por tu casa y me apuntaste con un revolver",
            "Desde ese día juré no vólver.",
            "Accion poetica",
            "Ayer pase por tu casa y me apuntaste con un revolver",
            "Desde ese día juré no vólver."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t.findViewById(R.id.txtV);
        lista = findViewById(R.id.listVwVista);
        lista.setAdapter(new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                asResta
        ));
        lista.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Toast.makeText(this, asResta[i], Toast.LENGTH_SHORT).show();
        /*t.setText(asResta[i]);*/
    }
}